package com.company;

public class TimeAndDate {
    public static void main(String[] args) {
        var x=java.time.LocalDateTime.now();
        System.out.println(x);
    }
}
