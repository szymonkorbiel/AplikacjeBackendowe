package com.company;

public class Splitter {
    public static void main(String[] args) {
        String text = "line 1\nline 2\nline 3\nline 4\n";
        String[] tab = text.split("\n");
        for (int i = 0; i < tab.length; i++) {
            System.out.println((i+1)+"."+tab[i]);
        }
    }
}
