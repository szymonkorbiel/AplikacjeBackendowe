package com.company;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInput {
    public static void main(String[] args) {
        FileInputStream fis = null;
        try{
            fis = new FileInputStream("plik.txt");
        }catch (FileNotFoundException e){
            System.out.println("Nie ma pliku");
            System.exit(1);
        }

        int bajt = 0;
        try{
            bajt= fis.read();
            while (bajt!= -1){
                System.out.print((char)bajt);
                bajt=fis.read();
            }
        }catch (IOException e){
            System.out.println("Blad odczytu");
            System.exit(2);
        }
        try {
            fis.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
