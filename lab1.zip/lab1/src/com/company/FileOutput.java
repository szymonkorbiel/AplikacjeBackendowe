package com.company;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class FileOutput {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        String fileName = "text.txt";
        try(FileOutputStream fos = new FileOutputStream(fileName); Scanner scan = new Scanner(System.in)){
            String text = scan.nextLine();
            byte[] bytes = text.getBytes();
            fos.write(bytes);
            fos.flush();
        }
    }
}
